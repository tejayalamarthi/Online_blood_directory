<?php
		function db(){
			$conn=mysqli_connect("localhost","root","","ikthss");
			return $conn;

		}


?>